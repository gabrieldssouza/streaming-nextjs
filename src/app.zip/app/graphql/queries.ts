import { gql } from '@apollo/client';

export const GET_POPULAR_MOVIES = gql`
  query GetPopularMovies {
    moviePopular(page: 1) {
      id
      title
      release_date
      poster_path
      overview
    }
  }
`;
