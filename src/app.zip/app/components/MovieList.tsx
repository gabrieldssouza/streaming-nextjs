import { gql, useQuery } from '@apollo/client';
import Image from 'next/image';
import {GET_POPULAR_MOVIES} from '../graphql/queries';

const MovieList = () => {
  const { loading, error, data } = useQuery(GET_POPULAR_MOVIES);

  if (loading) return <p>Loading...</p>;
  if (error) return <p>Error: {error.message}</p>;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {data.movies.map((movie: any) => (
        <div key={movie.title} className="p-4 border rounded-lg">
          <Image src={movie.poster} alt={movie.title} width={200} height={300} className="rounded-lg" />
          <h2 className="text-xl font-bold mt-2">{movie.title}</h2>
          <p className="text-gray-500">{movie.releaseDate}</p>
          <p className="mt-2">{movie.overview}</p>
        </div>
      ))}
    </div>
  );
};

export default MovieList;